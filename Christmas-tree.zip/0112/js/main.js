// document.addEventListener('DOMContentLoaded', () => {

//     let btn = document.querySelector('.button');

//     btn.addEventListener('click', () => {

//         let text = document.querySelector('h1');

//         text.style.fontSize = '10px';

//     })

// })